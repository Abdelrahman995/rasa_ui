# RASA-Chatbot-UI
A Chat widget easy to connect to RASA core bot to Custom Channel.

Added Support for 
- Buttons
- Images

Note: It works only with Rest Input Channel, for more details head on to https://rasa.com/docs/core/connectors/#restinput

![ScreenShot](https://github.com/JiteshGaikwad/RASA-Chatbot-UI/blob/master/ui1.PNG)

![ScreenShot](https://github.com/JiteshGaikwad/RASA-Chatbot-UI/blob/master/ui2.PNG)

https://www.youtube.com/watch?v=Bv1bWcZyV9g
